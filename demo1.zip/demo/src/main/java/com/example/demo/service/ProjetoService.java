package com.example.demo.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Projeto;
import com.example.demo.repository.ProjetoRepository;

@Service
public class ProjetoService {

  private ProjetoRepository projetoRepository;

  public ProjetoService(ProjetoRepository projetoRepository) {
    this.projetoRepository = projetoRepository;
  }

  public Iterable<Projeto> getProjetos() {
    return projetoRepository.findAll();
  }

  public Optional<Projeto> findById(@NonNull Long id) {
    return projetoRepository.findById(id);
  }

  public void salvar(Projeto projeto) {
    if (projeto == null) {
      throw new NullPointerException("Necessário o body da requisição");
    }
    if (projeto.getTitulo() == null) {
      throw new IllegalArgumentException("O campo titulo é obrigatório");
    }
    if (projeto.getDescricao() == null) {
      throw new IllegalArgumentException("O campo descricao é obrigatório");
    }
    if (projeto.getEntrega() == null) {
        throw new IllegalArgumentException("O campo entrega é obrigatório");
    }
    if (projeto.getStatus() == null) {
    throw new IllegalArgumentException("O campo status é obrigatório");
    }
    projetoRepository.save(projeto);
  }
  

  public void excluir(Long id) {

    Projeto projeto = projetoRepository.findById(id)
      .orElseThrow(() -> new IllegalStateException("Projeto não existe"));

      projetoRepository.delete(projeto);
  }
}
