package com.example.demo.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ModelProjeto {
 
  @JsonProperty(value = "codigo")
  private Long id;
  
  @JsonProperty("titulo")
  private String titulo;

  @JsonProperty("descricao")
  private String descricao;

  @JsonProperty("entrega")
  private LocalDateTime entrega;

  @JsonProperty("status")
  private String status;

  public ModelProjeto() {}

  public ModelProjeto(Long id, String Titulo, String descricao, LocalDateTime entrega, String Status) {
    this.id = id;
    this.titulo = titulo;
    this.descricao = descricao;
    this.entrega = entrega;
    this.status = status;
  }

  public String getStatus() {
    return status;
}

public void setStatus(String status) {
    this.status = status;
}

public String getTitulo() {
    return titulo;
}

public void setTitulo(String titulo) {
    this.titulo = titulo;
}

public String getDescricao() {
    return descricao;
}

public void setDescricao(String descricao) {
    this.descricao = descricao;
}

  public LocalDateTime getEntrega() {
    return entrega;
}

public void setEntrega(LocalDateTime entrega) {
    this.entrega = entrega;
}

public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  

}
