package com.example.demo.entity;


//import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "projetos")
public class Projeto { // Java Bean
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY) // sequencial
  private Long id;

  // Sem length considera 255
  @Column(length = 200, nullable = false)
  private String descricao;

  @Column(length = 50, nullable = false)
  @JsonProperty("nomeCompleto") // body/endpoint
  private String titulo;

  @Column(nullable = false)
  private LocalDateTime entrega;
 
  @Column(nullable = false)
  private String status;

  public String getStatus() {
    return status;
}

public void setStatus(String status) {
    this.status = status;
}

public String getTitulo() {
    return titulo;
}

public void setTitulo(String titulo) {
    this.titulo = titulo;
}

public String getDescricao() {
    return descricao;
}

public void setDescricao(String descricao) {
    this.descricao = descricao;
}

  public LocalDateTime getEntrega() {
    return entrega;
}

public void setEntrega(LocalDateTime entrega) {
    this.entrega = entrega;
}

public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

}
