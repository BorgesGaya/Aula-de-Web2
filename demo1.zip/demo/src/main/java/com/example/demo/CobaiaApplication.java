package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.ModelProjeto;
import com.example.demo.entity.Projeto;
import com.example.demo.repository.ProjetoRepository;
import com.example.demo.service.ProjetoService;
import jakarta.annotation.PostConstruct;


@SpringBootApplication
public class CobaiaApplication {
	@Autowired
	private ProjetoRepository projetoRepository;


	@Autowired
	private ProjetoService projetoService;

	public static void main(String[] args) {
		System.out.println("Algo");
		SpringApplication.run(CobaiaApplication.class, args);
	}

	@PostConstruct
	void popularBanco() {
		System.out.println("Populando o mochinho ...");

		Projeto a = new Projeto();
		a.setTitulo("Projeto do Marcio");
		a.setDescricao("marcio esteve aki!");
		a.setEntrega(LocalDateTime.now());
		a.setStatus("Novo");

		a = projetoRepository.save(a);

		Projeto b = new Projeto();
		b.setTitulo("Projeto do Marcio 2");
		b.setDescricao("marcio esteve aki novamente!");
		b.setEntrega(LocalDateTime.now());
		b.setStatus("Novo");

		b = projetoRepository.save(b);

		System.out.println(projetoRepository.getClass());

		System.out.println("Projeto salvo " + a.getId());

		System.out.println(projetoService.getProjetos());
	}

}
