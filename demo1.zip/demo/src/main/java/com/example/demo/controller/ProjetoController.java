package com.example.demo.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.ModelProjeto;
import com.example.demo.service.ProjetoService;

@RestController
public class ProjetoController {
      
  @GetMapping("/api/projetos/:{id}")
  public Map<String, Object> getProjeto() {
  
    return Map.of(
      "nome", "Marcio",
      "sobrenome", "Torres");
  }

  @GetMapping("/api/projeto")
  public Map<String, Object> getProjetos() {

    return Map.of("usuario", Map.of(
        "nome", "Marcio",
        "sobrenome", "Torres"));
  }

  @GetMapping("/api/projetos/:id/status")
  public Map<String, Object> statusProjeto() {
  
    return Map.of(
      "nome", "Marcio",
      "sobrenome", "Torres");
  }

  private final ProjetoService projetoService;

  public ProjetoController(ProjetoService projetoService) {
    this.projetoService = projetoService;
  }


    @DeleteMapping("/api/projeto/delete/{id}")
  public ResponseEntity<?> excluir(@PathVariable Long id) {

    try {
      projetoService.excluir(id);
      return ResponseEntity.ok().build(); // 200
    } catch (IllegalStateException e) {
      // return ResponseEntity.notFound().build();
      return ResponseEntity.noContent().build(); // 204 -> cacheável-repetível
    }

  }


  
  

  // public static void main(String[] args) throws Exception {
  //   Usuario u = new Usuario();
  //   u.setEmail("teste@teste.com");
  //   u.setId(12321312);

  //   ObjectMapper mapper = new ObjectMapper();

  //   System.out.println(mapper.writeValueAsString(u));

  //   Usuario u2 = mapper.readValue("{\"id\":888, \"email\": \"m@m.co\"}", Usuario.class);

  //   System.out.println(u2.getEmail());
  // }
}

